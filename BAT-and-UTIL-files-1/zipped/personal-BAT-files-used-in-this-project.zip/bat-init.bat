@call init-bat %*
